
document.addEventListener("DOMContentLoaded",()=>{
    const popup=document.getElementById("registrationPopup");
    const form=document.getElementById("registerForm");

    if(localStorage.getItem("elitezone_registered")){
        if(popup) popup.style.display="none";
    }

    if(form){
        form.addEventListener("submit",(e)=>{
            e.preventDefault();

            const data={
                name:document.getElementById("name").value,
                semester:document.getElementById("semester").value,
                roll:document.getElementById("roll").value,
                reg:document.getElementById("reg").value,
                college:document.getElementById("college").value,
                phone:document.getElementById("phone").value,
                email:document.getElementById("email").value
            };

            localStorage.setItem("elitezone_registered",JSON.stringify(data));
            alert("Registration Successful 🚀");
            popup.style.display="none";
        });
    }
});

function playVideo(title){
    alert("Playing: " + title + " inside premium popup player.");
}
