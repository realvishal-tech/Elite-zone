
# ELITE ZONE 🚀

Premium Coding Ecosystem for BCA Students.

## Features
- Premium futuristic UI
- Student Dashboard
- Admin Panel
- Batch System
- Registration Popup
- Mobile Responsive
- Glassmorphism Design
- Video Popup Logic
- Notes + Tests Sections

## Tech
- HTML
- CSS
- JavaScript

## Run
Open index.html in browser.
